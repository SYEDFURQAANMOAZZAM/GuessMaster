import { io } from 'socket.io-client';

export const socket = io(
  process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000',
  {
    autoConnect: false,
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
    transports: ['websocket', 'polling'],
  }
);